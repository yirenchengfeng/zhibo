#!/bin/bash
screen -ls >/home/id
first_line=$(head -n 2 /home/id | tail -n 1)
number_part=$(echo $first_line | awk -F '.' '{print $1}')
#echo $number_part
screen -X -S $number_part quit
killall ffmpeg
