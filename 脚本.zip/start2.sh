#!/bin/bash

# Function to stop screen sessions and kill ffmpeg process
stop_sessions() {
    screen -ls > /home/id
    first_line=$(head -n 2 /home/id | tail -n 1)
    number_part=$(echo $first_line | awk -F '.' '{print $1}')
    screen -X -S $number_part quit
    killall ffmpeg
}

# Define stream_start function 
stream_start(){
  # Define your original stream_start function content here
  rtmp=rtmp://x.rtmp.youtube.com/live2/zfry-uked-pyry-t8x2-77jd
  folder=/home/video2
  watermark=no
  if [ $watermark = "yes" ];then
    read -p "输入你的水印图片存放绝对路径,例如/opt/image/watermark.jpg (格式支持jpg/png/bmp):" image
    echo -e "${yellow} 添加水印完成,程序将开始推流. ${font}"
    while true; do
      cd $folder
      for video in $(ls *.mp4); do
        ffmpeg -re -i "$video" -i "$image" -filter_complex overlay=W-w-5:5 -c:v libx264 -c:a aac -b:a 192k -strict -2 -f flv ${rtmp}
      done
    done
  fi
  if [ $watermark = "no" ]; then
    while true; do
      cd $folder
      video=$(find ./ -type f | shuf -n 1)
      ffmpeg -re -i "$video" -preset ultrafast -vcodec libx264 -g 60 -b:v 1500k -c:a aac -b:a 128k -strict -2 -f flv ${rtmp}
    done
  fi
}

export -f stream_start

# Call the function to stop sessions
stop_sessions


# Start new session and execute commands
expect -c '
set env(TERM) "xterm"
set timeout -1
set sessionname "mysession"
spawn /usr/bin/screen -S $sessionname 
sleep 10
send "stream_start\n"
sleep 30
expect "rtmp://a.rtmp.youtube.com/live2/zfry-uked-pyry-t8x2-77jd"
sleep 10
send "\032"
'